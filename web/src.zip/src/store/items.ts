import { ItemData } from '../typings/item';

export const Items: {
  [key: string]: ItemData | undefined;
} = {
  water: {
    name: 'water',
    close: false,
    label: 'VODA',
    stack: true,
    usable: true,
    count: 0,
    rarity: 'legendary',
  },
  burger: {
    name: 'burger',
    close: false,
    label: 'BURGR',
    stack: false,
    usable: false,
    count: 0,
  },
  lockpick: {
    name: 'lockpick',
    close: false,
    label: 'LOCKPICK',
    stack: false,
    usable: true,
    count: 0,
  },
  backwoods: {
    name: 'backwoods',
    close: false,
    label: 'RUSSIAN CREAM',
    stack: false,
    usable: true,
    count: 0,
  },
};
