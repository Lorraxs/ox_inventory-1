export const Settings = {
  clothe_bucket: 'test2_clothe',
  autoTakingClothe: false,
};
